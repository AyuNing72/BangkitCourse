package com.example.github_user_navigationapi.data.model

data class UserResponse(
    val items : ArrayList<User>
)
